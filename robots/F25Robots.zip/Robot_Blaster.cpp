#include "RobotBase.h"
#include <vector>

class Robot_Blaster : public RobotBase
{
private:
    int target_row;
    int target_col;
    bool has_target;

public:
    Robot_Blaster() : RobotBase(2, 5, grenade), target_row(-1), target_col(-1), has_target(false) {}

    void get_radar_direction(int& radar_direction) override {
        radar_direction = 1; // Always scan up
    }

    void process_radar_results(const std::vector<RadarObj>& radar_results) override {
        has_target = false;
        for (const auto& obj : radar_results) {
            if (obj.m_type == 'R') {
                target_row = obj.m_row;
                target_col = obj.m_col;
                has_target = true;
                break;
            }
        }
    }

    bool get_shot_location(int& shot_row, int& shot_col) override {
        if (has_target && get_grenades() > 0) {
            shot_row = target_row;
            shot_col = target_col;
            has_target = false;
            return true;
        }
        return false;
    }

    void get_move_direction(int& move_direction, int& move_distance) override {
        move_direction = 0;
        move_distance = 0; // Don't move - stay hidden
    }
};

extern "C" RobotBase* create_robot() {
    return new Robot_Blaster();
}
