#include "RobotBase.h"
#include <vector>
#include <cmath>
#include <random>
#include <limits>
#include <algorithm>

// A simple railgun bot that looks for the nearest robot,
// shoots if it has a target, otherwise wanders.

class TannerSniper : public RobotBase {
private:
    bool m_hasTarget = false;
    int m_targetRow = -1;
    int m_targetCol = -1;

    int m_scanPhase = 0;  // used to vary radar direction when we see nothing

    std::mt19937 m_rng;

public:
    // Constructor: move = 4, armor = 3, weapon = railgun (4+3 = 7 points, valid config)
    TannerSniper()
        : RobotBase(/*move_in*/4, /*armor_in*/3, WeaponType::railgun)
    {
        m_name = "TannerSniper";
        m_character = '@';

        std::random_device rd;
        m_rng.seed(rd());
    }

    // 1) Tell arena where to aim radar
    void get_radar_direction(int& radar_direction) override {
        // Direction 0 = special "8 neighbors" scan handled by the arena.
        // We use it when we think we have a target so we can see nearby stuff.
        if (m_hasTarget) {
            radar_direction = 0;
        } else {
            // Just cycle 0..8 to get some variation when we don't see anyone
            radar_direction = m_scanPhase;
            m_scanPhase = (m_scanPhase + 1) % 9;
        }
    }

    // 2) Process radar results from arena
    void process_radar_results(const std::vector<RadarObj>& radar_results) override {
        m_hasTarget = false;
        m_targetRow = -1;
        m_targetCol = -1;

        int myRow, myCol;
        get_current_location(myRow, myCol);

        double bestDist = std::numeric_limits<double>::infinity();

        for (const auto& obj : radar_results) {
            if (obj.m_type != 'R') continue; // only care about live robots

            int dr = obj.m_row - myRow;
            int dc = obj.m_col - myCol;
            double d2 = static_cast<double>(dr) * dr + static_cast<double>(dc) * dc;

            if (d2 < bestDist) {
                bestDist = d2;
                m_targetRow = obj.m_row;
                m_targetCol = obj.m_col;
                m_hasTarget = true;
            }
        }
    }

    // 3) Decide whether to shoot, and where
    bool get_shot_location(int& shot_row, int& shot_col) override {
        if (!m_hasTarget) {
            // no shot: arena will call get_move_direction instead
            return false;
        }

        // For the railgun, the arena will use this as a point on the ray.
        shot_row = m_targetRow;
        shot_col = m_targetCol;
        return true;
    }

    // 4) Decide movement direction and distance if we didn't shoot
    void get_move_direction(int &direction, int &distance) override {
        int maxSpeed = get_move_speed();
        if (maxSpeed <= 0) {
            // Stuck (e.g., in a pit). Can't move.
            direction = 0;
            distance = 0;
            return;
        }

        int myRow, myCol;
        get_current_location(myRow, myCol);

        if (m_hasTarget) {
            // Move toward last seen target
            int dr = m_targetRow - myRow;
            int dc = m_targetCol - myCol;

            int rSign = (dr > 0) - (dr < 0); // 1, 0, or -1
            int cSign = (dc > 0) - (dc < 0);

            // Map (rSign, cSign) into the 1..8 direction encoding from RobotBase.h
            if (rSign == -1 && cSign == 0)       direction = 1; // up
            else if (rSign == -1 && cSign == 1)  direction = 2; // up-right
            else if (rSign == 0 && cSign == 1)   direction = 3; // right
            else if (rSign == 1 && cSign == 1)   direction = 4; // down-right
            else if (rSign == 1 && cSign == 0)   direction = 5; // down
            else if (rSign == 1 && cSign == -1)  direction = 6; // down-left
            else if (rSign == 0 && cSign == -1)  direction = 7; // left
            else if (rSign == -1 && cSign == -1) direction = 8; // up-left
            else {
                // Target is basically on top of us or weird case: don't move
                direction = 0;
                distance = 0;
                return;
            }

            int maxStepsToward = std::max(std::abs(dr), std::abs(dc));
            distance = std::min(maxSpeed, maxStepsToward);
        } else {
            // No target: wander slowly in a random direction
            std::uniform_int_distribution<int> dirDist(1, 8);
            direction = dirDist(m_rng);
            distance = 1;
        }
    }
};

// Factory function required by the arena/test harness
extern "C" RobotBase* create_robot() {
    return new TannerSniper();
}
