#include "RobotBase.h"
#include <vector>
#include <set>
#include <cmath>
#include <algorithm>
#include <limits>

class Robot_Sniper : public RobotBase
{
private:
    struct EnemyInfo
    {
        int row;
        int col;
        int last_seen_turn;

        EnemyInfo(int r, int c, int turn) : row(r), col(c), last_seen_turn(turn) {}
    };

    std::vector<EnemyInfo> known_enemies;
    int current_turn = 0;
    int target_enemy_idx = -1;

    int radar_direction = 1; 
    int radar_scan_count = 0;
    bool has_target = false;

    std::set<std::pair<int, int>> obstacles;
    std::set<std::pair<int, int>> dead_robots; 

    int preferred_direction = 0; 
    bool avoiding_danger = false;

    int manhattan_distance(int r1, int c1, int r2, int c2) const
    {
        return std::abs(r1 - r2) + std::abs(c1 - c2);
    }

    double euclidean_distance(int r1, int c1, int r2, int c2) const
    {
        return std::sqrt((r1 - r2) * (r1 - r2) + (c1 - c2) * (c1 - c2));
    }

    bool is_safe_position(int row, int col) const
    {
        if (obstacles.find({row, col}) != obstacles.end())
        {
            return false;
        }
        if (dead_robots.find({row, col}) != dead_robots.end())
        {
            return false;
        }
        if (row < 0 || row > m_board_row_max || col < 0 || col > m_board_col_max)
        {
            return false;
        }
        return true;
    }

    void update_enemies(const std::vector<RadarObj> &radar_results)
    {
        current_turn++;
        int current_row, current_col;
        get_current_location(current_row, current_col);

        for (auto &enemy : known_enemies)
        {
            enemy.last_seen_turn = -1; 
        }

        for (const auto &obj : radar_results)
        {
            if (obj.m_type == 'R')
            {
                bool found = false;
                for (auto &enemy : known_enemies)
                {
                    if (enemy.row == obj.m_row && enemy.col == obj.m_col)
                    {
                        enemy.last_seen_turn = current_turn;
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    known_enemies.push_back(EnemyInfo(obj.m_row, obj.m_col, current_turn));
                }
            }
            else if (obj.m_type == 'M' || obj.m_type == 'P' || obj.m_type == 'F')
            {
                obstacles.insert({obj.m_row, obj.m_col});
            }
            else if (obj.m_type == 'X')
            {
                dead_robots.insert({obj.m_row, obj.m_col});
            }
        }

        known_enemies.erase(
            std::remove_if(known_enemies.begin(), known_enemies.end(),
                           [this](const EnemyInfo &e)
                           {
                               return e.last_seen_turn < 0 || (current_turn - e.last_seen_turn) > 3;
                           }),
            known_enemies.end());
    }

    void select_target()
    {
        if (known_enemies.empty())
        {
            target_enemy_idx = -1;
            has_target = false;
            return;
        }

        int current_row, current_col;
        get_current_location(current_row, current_col);

        int best_idx = 0;
        int best_distance = manhattan_distance(current_row, current_col,
                                               known_enemies[0].row, known_enemies[0].col);

        for (size_t i = 1; i < known_enemies.size(); ++i)
        {
            int dist = manhattan_distance(current_row, current_col,
                                          known_enemies[i].row, known_enemies[i].col);
            if (dist < best_distance)
            {
                best_distance = dist;
                best_idx = i;
            }
        }

        target_enemy_idx = best_idx;
        has_target = true;
    }

    void calculate_safe_movement(int &direction, int &distance)
    {
        int current_row, current_col;
        get_current_location(current_row, current_col);

        if (!known_enemies.empty() && has_target && target_enemy_idx >= 0)
        {
            const auto &target = known_enemies[target_enemy_idx];
            int dist = manhattan_distance(current_row, current_col, target.row, target.col);

            if (dist < 5)
            {
                int dr = current_row - target.row;
                int dc = current_col - target.col;

                if (std::abs(dr) > std::abs(dc))
                {
                    direction = (dr > 0) ? 5 : 1; 
                }
                else
                {
                    direction = (dc > 0) ? 3 : 7; 
                }
                distance = std::min(4, get_move_speed());
                avoiding_danger = true;
                return;
            }
        }

        int center_row = m_board_row_max / 2;
        int center_col = m_board_col_max / 2;

        int dr = center_row - current_row;
        int dc = center_col - current_col;

        if (std::abs(dr) > std::abs(dc))
        {
            direction = (dr > 0) ? 5 : 1; 
        }
        else if (dc != 0)
        {
            direction = (dc > 0) ? 3 : 7; 
        }
        else
        {
            direction = (radar_direction % 8) + 1;
        }

        distance = std::min(3, get_move_speed()); 
        avoiding_danger = false;
    }

public:
    Robot_Sniper() : RobotBase(4, 3, railgun)
    {
        m_name = "Sniper";
    }

    virtual void get_radar_direction(int &radar_direction_out) override
    {
        if (has_target && target_enemy_idx >= 0)
        {
            int current_row, current_col;
            get_current_location(current_row, current_col);
            const auto &target = known_enemies[target_enemy_idx];

            int dr = target.row - current_row;
            int dc = target.col - current_col;

            if (dr < 0 && dc == 0)
                radar_direction_out = 1; 
            else if (dr < 0 && dc > 0)
                radar_direction_out = 2; 
            else if (dr == 0 && dc > 0)
                radar_direction_out = 3; 
            else if (dr > 0 && dc > 0)
                radar_direction_out = 4; 
            else if (dr > 0 && dc == 0)
                radar_direction_out = 5; 
            else if (dr > 0 && dc < 0)
                radar_direction_out = 6; 
            else if (dr == 0 && dc < 0)
                radar_direction_out = 7; 
            else if (dr < 0 && dc < 0)
                radar_direction_out = 8; 
            else
                radar_direction_out = 0; 
        }
        else
        {
            radar_direction_out = radar_direction;
            radar_direction = (radar_direction % 8) + 1; 
        }
    }

    virtual void process_radar_results(const std::vector<RadarObj> &radar_results) override
    {
        update_enemies(radar_results);
        select_target();
    }

    virtual bool get_shot_location(int &shot_row, int &shot_col) override
    {
        if (has_target && target_enemy_idx >= 0 &&
            target_enemy_idx < static_cast<int>(known_enemies.size()))
        {
            const auto &target = known_enemies[target_enemy_idx];
            shot_row = target.row;
            shot_col = target.col;
            return true;
        }
        return false;
    }

    virtual void get_move_direction(int &move_direction, int &move_distance) override
    {
        if (get_move_speed() == 0)
        {
            move_direction = 0;
            move_distance = 0;
            return;
        }

        calculate_safe_movement(move_direction, move_distance);

        int current_row, current_col;
        get_current_location(current_row, current_col);

        int delta_row = directions[move_direction].first;
        int delta_col = directions[move_direction].second;

        int new_row = current_row + delta_row * move_distance;
        int new_col = current_col + delta_col * move_distance;

        new_row = std::max(0, std::min(m_board_row_max, new_row));
        new_col = std::max(0, std::min(m_board_col_max, new_col));

        if (!is_safe_position(new_row, new_col))
        {
            for (int d = move_distance - 1; d > 0; --d)
            {
                int test_row = current_row + delta_row * d;
                int test_col = current_col + delta_col * d;
                test_row = std::max(0, std::min(m_board_row_max, test_row));
                test_col = std::max(0, std::min(m_board_col_max, test_col));

                if (is_safe_position(test_row, test_col))
                {
                    move_distance = d;
                    return;
                }
            }
            move_direction = (move_direction % 8) + 1;
            move_distance = 1;
        }
    }
};

extern "C" RobotBase *create_robot()
{
    return new Robot_Sniper();
}
