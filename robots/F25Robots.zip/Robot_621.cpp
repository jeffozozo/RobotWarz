#include "RobotBase.h"
#include <vector>
#include <iostream>
#include <algorithm>

class Robot_621 : public RobotBase 
{
private:
    bool m_moving_down = true;

    int to_shoot_row = -1;
    int to_shoot_col = -1;

    void clear_target()
    {
        to_shoot_row = -1;
        to_shoot_col = -1;
    }

public:
    Robot_621() : RobotBase(3, 4, railgun) {m_name = "621";}

    void get_radar_direction(int& radar_direction) override
    {
        radar_direction = 7;
    }

    
    void process_radar_results(const std::vector<RadarObj>& radar_results) override
    {
        clear_target();

        for (const auto& obj : radar_results)
        {
            if (obj.m_type == 'R' && to_shoot_row == -1)
            {
                to_shoot_row = obj.m_row;
                to_shoot_col = obj.m_col;
            }
        }
    }

    bool get_shot_location(int& shot_row, int& shot_col) override
    {
        if (to_shoot_row != -1)
        {
            shot_row = to_shoot_row;
            shot_col = to_shoot_col;
            clear_target();
            return true;
        }
        return false;
    }

    void get_move_direction(int& move_direction, int& move_distance) override
    {
        int current_row, current_col;
        get_current_location(current_row, current_col);
        int move = get_move_speed();

        if (current_col < m_board_col_max - 1)
        {
            move_direction = 3; // Right
            move_distance = std::min(move, (m_board_col_max - 1) - current_col);
            return;
        }



        if (m_moving_down)
        {
            if (current_row < m_board_row_max - 1)
            {
                move_direction = 5; 
                move_distance = std::min(move, (m_board_row_max - 1) - current_row);
            }
            else
            {
                
                m_moving_down = false;
                move_direction = 1;
                move_distance = std::min(move, current_row);
            }
        }
        else
        {
            
            if (current_row > 0)
            {
                move_direction = 1; 
                move_distance = std::min(move, current_row);
            }
            else
            {
                m_moving_down = true;
                move_direction = 5;
                move_distance = std::min(move, (m_board_row_max - 1) - current_row);
            }
        }
    }
};

extern "C" RobotBase* create_robot() 
{
    return new Robot_621();
}
