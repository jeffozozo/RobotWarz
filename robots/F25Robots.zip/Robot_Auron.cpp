#include "RobotBase.h"
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <limits>

// Only react to nearby enemies (within 2 spaces).
// Automatically attack if the enemy steps into hammer range.
// If multiple enemies appear, he backs away to avoid being surrounded.
// Prefers to hold his position when safe.
// Radar sweeps in a controlled 1-8 pattern to stay aware but not frantic.

class Robot_Auron : public RobotBase
{
private:
    int radar_dir = 1; // cycles 1–8
    bool enemy_close = false;
    
    // -1 = "I currently do not have a valid enemy location."
    int enemy_row = -1;
    int enemy_col = -1;

    // Auron can hit in all 8 directions (Chebyshev distance)
    bool in_hammer_range(int r1, int c1, int r2, int c2)
    {
        return std::max(std::abs(r1 - r2), std::abs(c1 - c2)) == 1;
    }

    // Check if closest enemy is within 2 tiles (Auron becomes alert)
    void find_near_enemy(const std::vector<RadarObj>& radar, int me_r, int me_c)
    {
        enemy_close = false;
        int closest = 999; // start with a huge distance

        for (const auto& obj : radar)
        {
            if (obj.m_type == 'R')
            {
                int d = std::abs(me_r - obj.m_row) + std::abs(me_c - obj.m_col);
                if (d < closest)
                {
                    closest = d; 
                    enemy_row = obj.m_row;
                    enemy_col = obj.m_col;
                    enemy_close = (closest <= 2); // only care if 1–2 tiles away
                }
            }
        }
    }

public:
    Robot_Auron()
        : RobotBase(1, 6, hammer) // slow, tanky, melee
    {
        m_name = "Auron";
        m_character = 'A';
    }

    // Slow, steady sweep of radar
    virtual void get_radar_direction(int& radar_direction) override
    {
        radar_direction = radar_dir;
        radar_dir = (radar_dir % 8) + 1; // Cycle through radar directions (1-8)
    }

    virtual void process_radar_results(const std::vector<RadarObj>& radar_results) override
    {
        int r, c;
        get_current_location(r, c);

        find_near_enemy(radar_results, r, c);
    }

    // Attack ONLY if enemy is exactly 1 tile away
    virtual bool get_shot_location(int& shot_row, int& shot_col) override
    {
        if (!enemy_close)
        {
            return false;
        }

        int r, c;
        get_current_location(r, c);

        if (in_hammer_range(r, c, enemy_row, enemy_col))
        {
            shot_row = enemy_row;
            shot_col = enemy_col;
            return true; // Auron counterattacks decisively
        }

        return false;
    }

    // Defensive movement:
    // - If enemy very close (<2 tiles), step backward if possible.
    // - Otherwise Auron stands still to defend.
    virtual void get_move_direction(int& direction, int& distance) override
    {
        direction = 0;
        distance = 0;

        if (!enemy_close)
        {
            // No threats nearby : Auron waits firmly
            return;
        }

        int r, c;
        get_current_location(r, c);

        // Enemy positions relative to Auron
        int dr = enemy_row - r;
        int dc = enemy_col - c;

        // Move AWAY from enemy (only 1 tile because he’s slow)
        if (std::abs(dr) > std::abs(dc))
        {
            direction = (dr > 0 ? 1 : 5); // enemy below: move up; enemy above: move down
        }
        else
        {
            direction = (dc > 0 ? 7 : 3); // enemy right: move left; enemy left: move right
        }

        distance = 1;
    }
};

// Factory function
extern "C" RobotBase* create_robot() {
    return new Robot_Auron();
}
