#include "RobotBase.h"
#include <vector>
#include <iostream>
#include <algorithm>
class Robot_Gunner : public RobotBase {
protected:
    bool m_moving_down = true;
    int to_shoot_row = -1;
    int to_shoot_col = -1;


    std::vector<RadarObj> known_obstacles;


    bool is_obstacle(int row, int col) const 
    {
        return std::any_of(known_obstacles.begin(), known_obstacles.end(), [&](const RadarObj& obj) {
            return obj.m_row == row && obj.m_col == col;
        });
    }

    void clear_target()
    {
        to_shoot_row = -1;
        to_shoot_col = -1;
    }

    void add_obstacle(const RadarObj& obj)
    {
        if(obj.m_type == 'M' || obj.m_type == 'P' || obj.m_type == 'F' && !is_obstacle(obj.m_row, obj.m_col))
            known_obstacles.push_back(obj);
    }


public:
    Robot_Gunner()
    :RobotBase(5, 20, railgun){

    }

    virtual void get_radar_direction(int& radar_direction) override 
    {
        int row, col;
        get_current_location(row, col);

        radar_direction = (col > 0) ? 7 : 3;
    }



    virtual void process_radar_results(const std::vector<RadarObj>& radar_results) override 
    {
        clear_target();
        for (const auto& obj : radar_results)
        {

            add_obstacle(obj);

            if(obj.m_type == 'R' && to_shoot_row == -1 && to_shoot_col == -1)
            {
                to_shoot_row = obj.m_row;
                to_shoot_col = obj.m_col;
            }
        }

    }

    virtual bool get_shot_location(int& shot_row, int& shot_col) override 
    {
        if(to_shoot_row != -1 && to_shoot_col != -1)
        {
            shot_row = to_shoot_row;
            shot_col = to_shoot_col;
            clear_target();
            return true;
        }
        return false;
    }

    void get_move_direction(int& move_direction, int& move_distance) override 
    {
        int row, col;
        get_current_location(row, col);
        int move = get_move_speed();


        if(col > 0)
        {
            move_direction = 7;
            move_distance = std::min(move, col);
            return;
        }

        if(m_moving_down)
        {
            if(row + move < m_board_row_max)
            {
                move_direction = 5;
                move_distance = std::min(move, m_board_row_max - row - 1);
            }
            else 
            {
                m_moving_down = false;
                move_direction = 1;
                move_distance = 1;
            }
        }
        else 
        {
            if(row - move >= 0)
            {
                move_direction = 1;
                move_distance = std::min(move, row);
            }
            else 
            {
                m_moving_down = true;
                move_direction = 5;
                move_distance = 1;
            }
        }
    }

};



extern "C" RobotBase* create_robot() 
{
    return new Robot_Gunner;
}