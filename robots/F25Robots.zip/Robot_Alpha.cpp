#include "RobotBase.h"
#include <vector>
#include <iostream>
#include <cmath>
#include <algorithm>

class Robot_Alpha : public RobotBase {
private:
    // Enemy tracking
    struct EnemyInfo {
        int row;
        int col;
        char type;
        int last_seen_round;
        int estimated_health;
        int times_hit;
        int last_row; // NEW: Track previous position for movement prediction
        int last_col;
        int velocity_row; // NEW: Estimated velocity
        int velocity_col;
        bool is_stationary; // NEW: Track if enemy is camping
    };
    
    std::vector<EnemyInfo> tracked_enemies;
    std::vector<RadarObj> known_obstacles;
    
    int current_round;
    int shots_fired;
    int shots_hit; // NEW: Track accuracy
    int last_hit_round;
    bool evading;
    int evasion_direction;
    int health_last_round;
    int armor_last_round; // NEW: Track armor changes
    int consecutive_hits_taken;
    int last_shot_row;
    int last_shot_col;
    bool last_shot_hit;
    int rounds_without_contact; // NEW: Track when we haven't seen enemies
    
    // Target selection
    int target_row;
    int target_col;
    int current_target_id;
    
    // Strategy parameters - ULTRA AGGRESSIVE
    const int CRITICAL_HEALTH = 15; // Was 30 - only panic when almost dead
    const int LOW_HEALTH = 35; // Was 50 - stay offensive much longer
    const int MODERATE_HEALTH = 55; // Was 70
    const int LOW_ARMOR_THRESHOLD = 1;
    const int FINISHING_MODE_THRESHOLD = 70; // Was 40 - trigger MUCH earlier!
    
    // Helper: Calculate Manhattan distance
    int manhattan_distance(int r1, int c1, int r2, int c2) const {
        return std::abs(r1 - r2) + std::abs(c1 - c2);
    }
    
    // Helper: Check if position is safe (no obstacles)
    bool is_safe_position(int row, int col) const {
        if (row < 0 || row >= m_board_row_max || col < 0 || col >= m_board_col_max) {
            return false;
        }
        
        for (const auto& obs : known_obstacles) {
            if (obs.m_row == row && obs.m_col == col) {
                return false;
            }
        }
        return true;
    }
    
    // Helper: Check if we're aligned with target (railgun requirement)
    bool is_aligned(int my_row, int my_col, int target_row, int target_col) const {
        return (my_row == target_row || my_col == target_col);
    }
    
    // NEW: Predict where enemy will be based on movement pattern
    void predict_enemy_position(const EnemyInfo& enemy, int& pred_row, int& pred_col) const {
        pred_row = enemy.row;
        pred_col = enemy.col;
        
        // If enemy has been moving, predict next position
        if (!enemy.is_stationary && (enemy.velocity_row != 0 || enemy.velocity_col != 0)) {
            pred_row += enemy.velocity_row;
            pred_col += enemy.velocity_col;
            
            // Clamp to board boundaries
            pred_row = std::max(0, std::min(m_board_row_max - 1, pred_row));
            pred_col = std::max(0, std::min(m_board_col_max - 1, pred_col));
        }
    }
    
    // Add or update obstacle in known list
    void update_obstacle(const RadarObj& obj) {
        if (obj.m_type == 'M' || obj.m_type == 'P' || obj.m_type == 'F') {
            bool found = false;
            for (const auto& obs : known_obstacles) {
                if (obs.m_row == obj.m_row && obs.m_col == obj.m_col) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                known_obstacles.push_back(obj);
            }
        }
    }
    
    // NEW: Check if position has nearby cover
    bool has_nearby_cover(int row, int col, int range) const {
        for (const auto& obs : known_obstacles) {
            if (obs.m_type == 'M') { // Mountains provide cover
                int dist = manhattan_distance(row, col, obs.m_row, obs.m_col);
                if (dist <= range && dist > 0) {
                    return true;
                }
            }
        }
        return false;
    }
    
    // Assess threat level of enemy based on position and stats
    int assess_threat(const EnemyInfo& enemy) const {
        int threat = 50;
        
        int current_row, current_col;
        const_cast<Robot_Alpha*>(this)->get_current_location(current_row, current_col);
        int dist = manhattan_distance(current_row, current_col, enemy.row, enemy.col);
        
        // Higher threat if enemy is close
        threat += (10 - dist) * 7;
        
        // Higher threat if we're aligned (they can shoot us)
        if (is_aligned(current_row, current_col, enemy.row, enemy.col)) {
            threat += 25;
        }
        
        // Lower threat if enemy appears damaged
        if (enemy.times_hit > 0) {
            threat -= enemy.times_hit * 5;
        }
        
        return threat;
    }
    
    // Get best evasion direction
    int get_evasion_direction(int my_row, int my_col) {
        int best_dir = 0;
        int best_score = -1000;
        
        for (int dir = 1; dir <= 8; ++dir) {
            auto d = directions[dir];
            int new_row = my_row + d.first * get_move_speed();
            int new_col = my_col + d.second * get_move_speed();
            
            if (!is_safe_position(new_row, new_col)) {
                continue;
            }
            
            int score = 0;
            
            // Calculate distance from all enemies
            int total_enemy_dist = 0;
            int min_enemy_dist = 1000;
            for (const auto& enemy : tracked_enemies) {
                int dist = manhattan_distance(new_row, new_col, enemy.row, enemy.col);
                total_enemy_dist += dist;
                min_enemy_dist = std::min(min_enemy_dist, dist);
            }
            score += total_enemy_dist * 3;
            
            // Huge bonus for not being aligned with any enemy
            bool aligned_with_enemy = false;
            for (const auto& enemy : tracked_enemies) {
                if (is_aligned(new_row, new_col, enemy.row, enemy.col)) {
                    aligned_with_enemy = true;
                    break;
                }
            }
            if (!aligned_with_enemy) {
                score += 40;
            }
            
            // Bonus for positions near cover
            if (has_nearby_cover(new_row, new_col, 2)) {
                score += 25;
            }
            
            // Avoid edges when evading
            int edge_dist = std::min({new_row, m_board_row_max - new_row - 1,
                                     new_col, m_board_col_max - new_col - 1});
            score += edge_dist * 2;
            
            // Zigzag bonus - alternate between perpendicular directions
            if (dir % 2 == current_round % 2) {
                score += 15;
            }
            
            if (score > best_score) {
                best_score = score;
                best_dir = dir;
            }
        }
        
        return best_dir > 0 ? best_dir : 1;
    }
    
    // Get direction to align for railgun shot
    int get_alignment_direction(int my_row, int my_col, int tgt_row, int tgt_col) {
        // Already aligned vertically
        if (my_col == tgt_col) {
            if (my_row < tgt_row) return 5; // Move down closer
            if (my_row > tgt_row) return 1; // Move up closer
            return 0;
        }
        
        // Already aligned horizontally
        if (my_row == tgt_row) {
            if (my_col < tgt_col) return 3; // Move right closer
            if (my_col > tgt_col) return 7; // Move left closer
            return 0;
        }
        
        // Need to align - choose based on which is closer
        int row_diff = std::abs(my_row - tgt_row);
        int col_diff = std::abs(my_col - tgt_col);
        
        if (row_diff < col_diff) {
            // Align horizontally (move to same row)
            if (my_row < tgt_row) return 5; // Move down
            if (my_row > tgt_row) return 1; // Move up
        } else {
            // Align vertically (move to same column)
            if (my_col < tgt_col) return 3; // Move right
            if (my_col > tgt_col) return 7; // Move left
        }
        
        return 1; // Default
    }

    // Get optimal engagement distance based on our health AND enemy count
    int get_optimal_distance() {
        int health = get_health();
        int armor = get_armor();
        int enemy_count = tracked_enemies.size();
        
        // Critical condition - keep max distance
        if (health < CRITICAL_HEALTH || (armor == 0 && consecutive_hits_taken > 0)) {
            return 10;
        }
        
        // Outnumbered - be more defensive
        if (enemy_count > 2) {
            return 9;
        }
        
        // Low health - defensive distance
        if (health < LOW_HEALTH) {
            return 7; // Reduced from 8 for better accuracy
        }
        
        // Moderate health - balanced distance
        if (health < MODERATE_HEALTH) {
            return 5; // Reduced from 6
        }
        
        // Good health - aggressive
        if (enemy_count == 1) {
            return 4; // Even closer for 1v1
        }
        
        return 5;
    }
    
    // Check if we should enter finishing mode
    bool should_finish_aggressively() {
        // Only one or two enemies left
        if (tracked_enemies.size() > 2) {
            return false;
        }
        
        // Count heavily damaged enemies
        int damaged_enemies = 0;
        int total_estimated_health = 0;
        
        for (const auto& enemy : tracked_enemies) {
            total_estimated_health += enemy.estimated_health;
            if (enemy.times_hit >= 2 || enemy.estimated_health < FINISHING_MODE_THRESHOLD) {
                damaged_enemies++;
            }
        }
        
        // If most/all enemies are damaged, finish them
        if (damaged_enemies >= (int)tracked_enemies.size()) {
            return true;
        }
        
        // Single enemy that's damaged
        if (tracked_enemies.size() == 1) {
            const auto& enemy = tracked_enemies[0];
            // More aggressive finishing threshold
            if (enemy.times_hit >= 2 || enemy.estimated_health < 50) {
                return true;
            }
            
            // We have health advantage - press it
            if (get_health() >= 50 && enemy.estimated_health < get_health()) {
                return true;
            }
        }
        
        // We have good health AND enemies are collectively weak
        if (get_health() >= 60 && total_estimated_health < get_health() * 1.5) {
            return true;
        }
        
        return false;
    }

    // Select best target based on threat and tactical advantage
    bool select_target(int my_row, int my_col) {
        if (tracked_enemies.empty()) {
            return false;
        }
        
        int best_score = -1000;
        int best_idx = -1;
        int optimal_dist = get_optimal_distance();
        
        for (size_t i = 0; i < tracked_enemies.size(); ++i) {
            const auto& enemy = tracked_enemies[i];
            int score = assess_threat(enemy);
            
            int dist = manhattan_distance(my_row, my_col, enemy.row, enemy.col);
            
            // HUGE bonus for being aligned (can shoot immediately)
            if (is_aligned(my_row, my_col, enemy.row, enemy.col)) {
                score += 50; // Increased from 30
            }
            
            // Prefer enemies near our optimal distance
            int dist_from_optimal = std::abs(dist - optimal_dist);
            score -= dist_from_optimal * 4; // Reduced penalty
            
            // PRIORITIZE damaged enemies heavily
            if (enemy.times_hit > 0) {
                score += enemy.times_hit * 25; // Increased from 15
            }
            
            // Low health enemies are high priority
            if (enemy.estimated_health < FINISHING_MODE_THRESHOLD) {
                score += 60; // Increased from 40
            }
            
            // Very low health - MAXIMUM priority
            if (enemy.estimated_health < 20) {
                score += 100;
            }
            
            // Stationary enemies are easier targets
            if (enemy.is_stationary) {
                score += 20;
            }
            
            // Target consistency bonus (but not too sticky)
            if ((int)i == current_target_id && enemy.times_hit > 0) {
                score += 15; // Reduced from 20
            }
            
            // Avoid switching targets if current is damaged
            if ((int)i != current_target_id && current_target_id >= 0 && 
                current_target_id < (int)tracked_enemies.size()) {
                if (tracked_enemies[current_target_id].times_hit >= 2) {
                    score -= 30; // Penalty for switching away from wounded target
                }
            }
            
            if (score > best_score) {
                best_score = score;
                best_idx = i;
            }
        }
        
        if (best_idx >= 0) {
            // Use predicted position for moving targets
            predict_enemy_position(tracked_enemies[best_idx], target_row, target_col);
            current_target_id = best_idx;
            return true;
        }
        
        return false;
    }

public:
    Robot_Alpha() : RobotBase(5, 2, railgun) {
        current_round = 0;
        shots_fired = 0;
        shots_hit = 0;
        last_hit_round = -10;
        evading = false;
        evasion_direction = 1;
        target_row = -1;
        target_col = -1;
        health_last_round = 100;
        armor_last_round = 2;
        consecutive_hits_taken = 0;
        last_shot_row = -1;
        last_shot_col = -1;
        last_shot_hit = false;
        current_target_id = -1;
        rounds_without_contact = 0;
    }
    
    virtual void get_radar_direction(int& radar_direction) override {
        // IMPROVED: More aggressive scanning when no enemies detected
        if (tracked_enemies.empty() || rounds_without_contact > 3) {
            // Full 360 sweep when searching
            radar_direction = (current_round % 8) + 1;
            if (radar_direction > 8) radar_direction = 0;
        } else {
            // Focused scanning when tracking enemies
            if (current_round % 3 == 0) {
                radar_direction = 7; // Left
            } else if (current_round % 3 == 1) {
                radar_direction = 3; // Right
            } else {
                radar_direction = 0; // Omnidirectional
            }
        }
        
        current_round++;
    }
    
    virtual void process_radar_results(const std::vector<RadarObj>& radar_results) override {
        // Check if we took damage
        int current_health = get_health();
        int current_armor = get_armor();
        int damage_taken = health_last_round - current_health;
        int armor_lost = armor_last_round - current_armor;
        
        if (damage_taken > 0 || armor_lost > 0) {
            evading = true;
            last_hit_round = current_round;
            consecutive_hits_taken++;
        } else {
            consecutive_hits_taken = std::max(0, consecutive_hits_taken - 1);
        }
        health_last_round = current_health;
        armor_last_round = current_armor;
        
        // Check if our last shot hit by comparing with previous enemy positions
        last_shot_hit = false;
        if (last_shot_row >= 0 && !tracked_enemies.empty()) {
            bool found_at_shot_location = false;
            for (const auto& obj : radar_results) {
                if (obj.m_type == 'R' && obj.m_row == last_shot_row && obj.m_col == last_shot_col) {
                    found_at_shot_location = true;
                    break;
                }
            }
            // If enemy was there before but not now, we hit
            if (!found_at_shot_location && current_target_id >= 0 && 
                current_target_id < (int)tracked_enemies.size()) {
                const auto& prev = tracked_enemies[current_target_id];
                if (prev.row == last_shot_row && prev.col == last_shot_col) {
                    last_shot_hit = true;
                    shots_hit++;
                }
            }
        }
        
        // Save old enemy data for comparison
        std::vector<EnemyInfo> old_enemies = tracked_enemies;
        tracked_enemies.clear();
        
        // Process radar results
        std::vector<EnemyInfo> new_enemies;
        for (const auto& obj : radar_results) {
            update_obstacle(obj);
            
            if (obj.m_type == 'R') {
                EnemyInfo enemy;
                enemy.row = obj.m_row;
                enemy.col = obj.m_col;
                enemy.type = 'R';
                enemy.last_seen_round = current_round;
                enemy.times_hit = 0;
                enemy.estimated_health = 100;
                enemy.last_row = obj.m_row;
                enemy.last_col = obj.m_col;
                enemy.velocity_row = 0;
                enemy.velocity_col = 0;
                enemy.is_stationary = false;
                
                // Match with previously tracked enemy
                bool matched = false;
                for (const auto& old_enemy : old_enemies) {
                    int dist = manhattan_distance(old_enemy.row, old_enemy.col, enemy.row, enemy.col);
                    if (dist <= 5) { // Enemies can move up to 5 spaces
                        // Copy tracking data
                        enemy.times_hit = old_enemy.times_hit;
                        enemy.estimated_health = old_enemy.estimated_health;
                        enemy.last_row = old_enemy.row;
                        enemy.last_col = old_enemy.col;
                        
                        // Calculate velocity
                        enemy.velocity_row = enemy.row - old_enemy.row;
                        enemy.velocity_col = enemy.col - old_enemy.col;
                        
                        // Check if stationary
                        enemy.is_stationary = (enemy.velocity_row == 0 && enemy.velocity_col == 0);
                        
                        // If we hit them, update
                        if (last_shot_hit && current_target_id >= 0) {
                            for (size_t j = 0; j < old_enemies.size(); ++j) {
                                if ((int)j == current_target_id && 
                                    manhattan_distance(old_enemies[j].row, old_enemies[j].col, 
                                                     enemy.row, enemy.col) <= 1) {
                                    enemy.times_hit++;
                                    enemy.estimated_health = std::max(0, enemy.estimated_health - 10);
                                    break;
                                }
                            }
                        }
                        
                        matched = true;
                        break;
                    }
                }
                
                // New enemy detected
                if (!matched) {
                    // Estimate based on game state
                    if (current_round > 20 && shots_fired > 5) {
                        enemy.estimated_health = 70; // Likely took some damage
                    } else {
                        enemy.estimated_health = 100;
                    }
                }
                
                new_enemies.push_back(enemy);
            }
        }
        
        tracked_enemies = new_enemies;
        
        // Track rounds without enemy contact
        if (tracked_enemies.empty()) {
            rounds_without_contact++;
        } else {
            rounds_without_contact = 0;
        }
        
        // NEW: LATE GAME AGGRESSION - After round 50, be extremely aggressive
        if (current_round > 50 && !tracked_enemies.empty()) {
            evading = false; // Stop evading in late game - go for the kill!
        }
        
        // IMPROVED: In finishing mode, be more aggressive
        if (should_finish_aggressively()) {
            if (current_round - last_hit_round > 2) {
                evading = false;
            }
        }
        
        // Shorter evasion time for better offense
        int evasion_time = (consecutive_hits_taken > 2) ? 3 : 1; // Even shorter! Was 4:2
        
        if (evading) {
            if (should_finish_aggressively() && get_health() > 40) {
                evasion_time = 1; // Very short evasion in finishing mode
            }
            
            // Late game - minimal evasion
            if (current_round > 80) {
                evasion_time = 1;
            }
            
            if (current_round - last_hit_round > evasion_time) {
                evading = false;
            }
        }
    }
    
    virtual bool get_shot_location(int& shot_row, int& shot_col) override {
        int my_row, my_col;
        get_current_location(my_row, my_col);
        
        bool finishing_mode = should_finish_aggressively();
        int optimal_dist = get_optimal_distance();
        
        // NEW: LATE GAME - Shoot aggressively after round 75
        bool late_game = current_round > 75;
        
        // IMPROVED: More aggressive shooting conditions
        // Don't shoot while evading ONLY if critically damaged AND not late game
        if (evading && get_health() < CRITICAL_HEALTH && !finishing_mode && !late_game) {
            return false;
        }
        
        // In late game, ignore armor concerns - just shoot!
        if (!late_game && get_armor() == 0 && (current_round - last_hit_round) < 1 && 
            !finishing_mode && !is_aligned(my_row, my_col, target_row, target_col)) {
            return false;
        }
        
        // Find best target
        if (select_target(my_row, my_col)) {
            int dist = manhattan_distance(my_row, my_col, target_row, target_col);
            
            // Only shoot if aligned (railgun requirement)
            if (is_aligned(my_row, my_col, target_row, target_col)) {
                // LATE GAME: Shoot from ANY distance if aligned!
                if (late_game && dist >= 1) {
                    shot_row = target_row;
                    shot_col = target_col;
                    last_shot_row = shot_row;
                    last_shot_col = shot_col;
                    shots_fired++;
                    return true;
                }
                
                // In finishing mode, shoot from ANY distance if aligned
                if (finishing_mode && dist >= 2) {
                    shot_row = target_row;
                    shot_col = target_col;
                    last_shot_row = shot_row;
                    last_shot_col = shot_col;
                    shots_fired++;
                    return true;
                }
                
                // Normal mode - shoot if in good range
                bool in_range = (dist >= 2 && dist <= optimal_dist + 4);
                if (in_range || dist <= 3) {
                    shot_row = target_row;
                    shot_col = target_col;
                    last_shot_row = shot_row;
                    last_shot_col = shot_col;
                    shots_fired++;
                    return true;
                }
            }
        }
        
        last_shot_row = -1;
        return false;
    }
    
    virtual void get_move_direction(int& move_direction, int& move_distance) override {
        int my_row, my_col;
        get_current_location(my_row, my_col);
        
        move_distance = get_move_speed();
        
        bool finishing_mode = should_finish_aggressively();
        int optimal_dist = get_optimal_distance();
        bool late_game = current_round > 70; // NEW: Track late game
        
        // CRITICAL HEALTH - Maximum evasion priority (but not in late game)
        if (get_health() < CRITICAL_HEALTH && !late_game) {
            move_direction = get_evasion_direction(my_row, my_col);
            move_distance = get_move_speed();
            return;
        }
        
        // LATE GAME: Be aggressive even with low armor/health
        if (late_game && get_armor() == 0 && consecutive_hits_taken > 1 && get_health() < CRITICAL_HEALTH) {
            // Still evade in late game if critically hurt
            move_direction = get_evasion_direction(my_row, my_col);
            move_distance = get_move_speed();
            return;
        }
        
        // Currently evading (but not in finishing mode OR late game)
        if (evading && !(finishing_mode && get_health() > 40) && !late_game) {
            move_direction = get_evasion_direction(my_row, my_col);
            return;
        }
        
        // LOW HEALTH - Defensive movement (unless finishing OR late game)
        if (get_health() < LOW_HEALTH && !finishing_mode && !late_game) {
            if (tracked_enemies.empty()) {
                move_direction = get_evasion_direction(my_row, my_col);
                move_distance = 2;
                return;
            }
            
            if (select_target(my_row, my_col)) {
                int dist = manhattan_distance(my_row, my_col, target_row, target_col);
                
                if (dist < optimal_dist) {
                    // Back away while maintaining line of sight
                    if (my_row == target_row) {
                        move_direction = (my_col < target_col) ? 7 : 3;
                    } else if (my_col == target_col) {
                        move_direction = (my_row < target_row) ? 1 : 5;
                    } else {
                        move_direction = get_evasion_direction(my_row, my_col);
                    }
                    return;
                }
            }
        }
        
        // No enemies - AGGRESSIVE SEARCH in late game
        if (tracked_enemies.empty()) {
            if (late_game) {
                // Late game with no enemies visible - search aggressively
                // Spiral outward from center
                move_direction = ((current_round / 2) % 8) + 1;
                move_distance = get_move_speed(); // Full speed search
            } else {
                // Early game patrol
                int center_row = m_board_row_max / 2;
                int center_col = m_board_col_max / 2;
                
                if (std::abs(my_row - center_row) > 5 || std::abs(my_col - center_col) > 5) {
                    if (my_row < center_row) move_direction = 5;
                    else if (my_row > center_row) move_direction = 1;
                    else if (my_col < center_col) move_direction = 3;
                    else move_direction = 7;
                    move_distance = 3;
                } else {
                    move_direction = ((current_round / 3) % 4) * 2 + 1;
                    move_distance = 2;
                }
            }
            return;
        }
        
        // Has target - execute strategy
        if (select_target(my_row, my_col)) {
            int dist = manhattan_distance(my_row, my_col, target_row, target_col);
            
            // LATE GAME OR FINISHING MODE - Maximum aggression
            if (finishing_mode || late_game) {
                if (dist > 6) {
                    // Close distance aggressively
                    move_direction = get_alignment_direction(my_row, my_col, target_row, target_col);
                    move_distance = get_move_speed();
                    return;
                }
                
                if (dist >= 3 && dist <= 6) {
                    if (!is_aligned(my_row, my_col, target_row, target_col)) {
                        // Align for shot quickly
                        move_direction = get_alignment_direction(my_row, my_col, target_row, target_col);
                        move_distance = get_move_speed();
                    } else {
                        // Aligned - press the attack
                        if (dist > 4) {
                            if (my_row == target_row) {
                                move_direction = (my_col < target_col) ? 3 : 7;
                            } else {
                                move_direction = (my_row < target_row) ? 5 : 1;
                            }
                            move_distance = late_game ? 3 : 2; // Even more aggressive in late game
                        } else {
                            move_direction = get_alignment_direction(my_row, my_col, target_row, target_col);
                            move_distance = 1;
                        }
                    }
                    return;
                }
                
                if (dist < 3) {
                    // Back up slightly but stay aligned
                    if (my_row == target_row) {
                        move_direction = (my_col < target_col) ? 7 : 3;
                    } else {
                        move_direction = (my_row < target_row) ? 1 : 5;
                    }
                    move_distance = 1;
                    return;
                }
            }
            
            // NORMAL MODE
            if (dist < optimal_dist - 1) {
                // Too close
                if (is_aligned(my_row, my_col, target_row, target_col)) {
                    if (my_row == target_row) {
                        move_direction = (my_col < target_col) ? 7 : 3;
                    } else {
                        move_direction = (my_row < target_row) ? 1 : 5;
                    }
                } else {
                    move_direction = get_evasion_direction(my_row, my_col);
                }
                move_distance = get_move_speed();
                return;
            }
            
            // Not aligned - get aligned
            if (dist >= optimal_dist - 1 && dist <= optimal_dist + 3 && 
                !is_aligned(my_row, my_col, target_row, target_col)) {
                move_direction = get_alignment_direction(my_row, my_col, target_row, target_col);
                move_distance = std::min(2, get_move_speed());
                return;
            }
            
            // Too far - approach
            if (dist > optimal_dist + 3) {
                move_direction = get_alignment_direction(my_row, my_col, target_row, target_col);
                move_distance = std::min(3, get_move_speed());
                return;
            }
            
            // Optimal range and aligned - strafe
            if (is_aligned(my_row, my_col, target_row, target_col)) {
                if (my_row == target_row) {
                    move_direction = (current_round % 2 == 0) ? 1 : 5;
                } else {
                    move_direction = (current_round % 2 == 0) ? 3 : 7;
                }
                move_distance = 1;
                return;
            }
        }
        
        // Default - move aggressively toward center
        move_direction = 3;
        move_distance = 2;
    }
};

extern "C" RobotBase* create_robot() {
    return new Robot_Alpha();
}
