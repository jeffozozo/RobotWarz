#include "RobotBase.h"
#include <vector>
#include <iostream>
#include <cmath>

class Robot_Grenadier : public RobotBase 
{
private:
    // Simple enemy tracking
    struct EnemyPos {
        int row;
        int col;
    };
    
    std::vector<EnemyPos> known_enemies;
    int scan_direction = 1;
    
    // Grenade target
    int target_grenade_row = -1;
    int target_grenade_col = -1;
    
    // Basic stats
    int turn_count = 0;

public:
    Robot_GrenadeAmbush() : RobotBase(0, 7, grenade) {
        m_name = "Grenadier";
        m_character = 'G';
    }

    virtual void get_radar_direction(int& radar_direction) override {
        turn_count++;
        radar_direction = scan_direction;
        scan_direction++;
        if (scan_direction > 8) scan_direction = 1;
    }

    virtual void process_radar_results(const std::vector<RadarObj>& radar_results) override {
        // Clear old enemies - simple approach
        known_enemies.clear();
        
        // Add all visible enemies (live robots only)
        for (const auto& obj : radar_results) {
            // Live robots are characters A-Z (except ourselves)
            if (obj.m_type >= 'A' && obj.m_type <= 'Z' && obj.m_type != m_character) {
                known_enemies.push_back({obj.m_row, obj.m_col});
            }
        }
        
        // Look for grenade opportunities (2+ enemies close together)
        if (known_enemies.size() >= 2 && get_grenades() > 0) {
            // Check all enemy pairs
            for (size_t i = 0; i < known_enemies.size(); ++i) {
                for (size_t j = i + 1; j < known_enemies.size(); ++j) {
                    int row_diff = std::abs(known_enemies[i].row - known_enemies[j].row);
                    int col_diff = std::abs(known_enemies[i].col - known_enemies[j].col);
                    
                    // If enemies are within grenade radius (3 tiles)
                    if (row_diff <= 3 && col_diff <= 3) {
                        // Place grenade between them
                        target_grenade_row = (known_enemies[i].row + known_enemies[j].row) / 2;
                        target_grenade_col = (known_enemies[i].col + known_enemies[j].col) / 2;
                        
                        std::cout << m_name << ": Found targets at (" 
                                  << known_enemies[i].row << "," << known_enemies[i].col 
                                  << ") and (" << known_enemies[j].row << "," << known_enemies[j].col 
                                  << ")" << std::endl;
                        return;
                    }
                }
            }
        }
        
        // No good target found
        target_grenade_row = -1;
        target_grenade_col = -1;
    }

    virtual bool get_shot_location(int& shot_row, int& shot_col) override {
        // Only shoot if we have a valid grenade target AND grenades left
        if (target_grenade_row != -1 && get_grenades() > 0) {
            shot_row = target_grenade_row;
            shot_col = target_grenade_col;
            
            std::cout << m_name << ": Throwing grenade at (" 
                      << shot_row << "," << shot_col << ")" << std::endl;
            
            // Clear target after deciding to shoot
            target_grenade_row = -1;
            target_grenade_col = -1;
            
            return true;
        }
        
        return false;
    }

    virtual void get_move_direction(int& move_direction, int& move_distance) override {
        // Stationary ambusher - never moves
        move_direction = 0;
        move_distance = 0;
    }
};

extern "C" RobotBase* create_robot() {
    return new Robot_Grenadier();
}