#include "RobotBase.h"
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <set>
#include <limits>
#include <climits>
#include <cstdlib>
#include <ctime>

struct EnemyTrack {
    int row = -1;
    int col = -1;
    int prev_row = -1;
    int prev_col = -1;
    int seen_ticks = 0;
    int last_seen_turn = -1;
};

class Robot_Atlus : public RobotBase {
public:
    Robot_Atlus() : RobotBase(2, 2, WeaponType::railgun) {
        m_name = "Atlus";
        // Position tracking
        self_row = 2; self_col = 2;
        // Oracle-style state
        last_dir = 2;           // start facing East
        turn_counter = 0;
        mode = Mode::Search;
        sweep_length = 1;
        sweep_count = 0;
        sweep_turns = 0;
        sweep_dir = 1;          // start North
        kiting_toggle = false;
        // Luffy-style strategy
        strategyMode = 0;
        turnsTaken = 0;
        firstMoveDone = false;
        mode_toggle = false;
        has_adjacent_target = false;
        target_row = -1; target_col = -1;
        std::srand(static_cast<unsigned int>(std::time(nullptr)));
    }

    // Radar direction: prioritize directional scans in Engage/Pressure, otherwise periodic full scan
    void get_radar_direction(int& radar_direction) override {
        switch (mode) {
            case Mode::Engage:
            case Mode::Pressure:
                radar_direction = last_dir;
                break;
            case Mode::Search:
            default:
                radar_direction = (turn_counter % 4 == 0) ? 0 : last_dir; // 0 = broad scan
                break;
        }
    }

    void process_radar_results(const std::vector<RadarObj>& results) override {
        turn_counter++;
        lastRadarScan = results;

        // Track obstacles (from Flame_e_o)
        update_obstacle_memory(results);

        // Update enemy tracks (Oracle)
        for (const auto& obj : results) {
            if (obj.m_type != 'R') continue;
            int key = obj.m_row * 100 + obj.m_col; // board is 20x20, safe enough
            auto& tr = tracks[key];
            tr.prev_row = tr.row;
            tr.prev_col = tr.col;
            tr.row = obj.m_row;
            tr.col = obj.m_col;
            tr.seen_ticks++;
            tr.last_seen_turn = turn_counter;
        }

        // Prune stale tracks
        for (auto it = tracks.begin(); it != tracks.end(); ) {
            if (turn_counter - it->second.last_seen_turn > 6) {
                it = tracks.erase(it);
            } else {
                ++it;
            }
        }

        // Adjacent target info (Luffy close-quarters fallback)
        has_adjacent_target = false;
        for (const auto& obj : results) {
            if (obj.m_type == 'R') {
                int dRow = std::abs(obj.m_row - self_row);
                int dCol = std::abs(obj.m_col - self_col);
                if ((dRow + dCol) == 1) {
                    target_row = obj.m_row;
                    target_col = obj.m_col;
                    has_adjacent_target = true;
                    break;
                }
            }
        }

        // Pick best target and predict next position (Oracle)
        has_target = false;
        predicted_row = -1;
        predicted_col = -1;
        int best_score = INT_MIN;

        for (const auto& kv : tracks) {
            const auto& tr = kv.second;
            if (tr.row < 0 || tr.col < 0) continue;

            int drow = (tr.prev_row >= 0) ? (tr.row - tr.prev_row) : 0;
            int dcol = (tr.prev_col >= 0) ? (tr.col - tr.prev_col) : 0;

            int prow = tr.row + drow;   // single-step inertia
            int pcol = tr.col + dcol;

            int stability = (std::abs(drow) + std::abs(dcol) == 0) ? 2 : 1;
            int recency = std::max(0, 6 - (turn_counter - tr.last_seen_turn));
            int score = 20 * stability + 15 * recency;
            if (drow == 0 || dcol == 0) score += 10; // axis-aligned bonus

            if (score > best_score) {
                best_score = score;
                predicted_row = std::clamp(prow, 0, 19);
                predicted_col = std::clamp(pcol, 0, 19);
                has_target = true;
            }
        }

        // Mode selection (combined logic)
        if (has_target) {
            mode = Mode::Engage;
        } else {
            bool had_recent = false;
            for (const auto& kv : tracks) {
                if (turn_counter - kv.second.last_seen_turn <= 3) {
                    had_recent = true; break;
                }
            }
            mode = had_recent ? Mode::Pressure : Mode::Search;
        }
    }

    bool get_shot_location(int& row, int& col) override {
        // Railgun: fire at predicted best target if available
        switch (has_target ? 1 : 0) {
            case 1:
                row = predicted_row;
                col = predicted_col;
                return true;
            default:
                return false;
        }
    }

    void get_move_direction(int& dir, int& dist) override {
        // Emergency dodge if armor or health is low (Oracle-style safety)
        if (get_armor() <= 1 || get_health() <= 20) {
            kiting_toggle = !kiting_toggle;
            dir = kiting_toggle ? 1 : 2; // N/E dodge
            dist = 1;
            last_dir = dir;
            updatePosition(dir, dist);
            return;
        }

        // High-level mode switch (blend of Oracle modes + Luffy firstMove/strategy)
        int highMode = 0;
        if (!firstMoveDone)       highMode = 1; // First move (Luffy)
        else if (mode == Mode::Engage)   highMode = 2;
        else if (mode == Mode::Pressure) highMode = 3;
        else                              highMode = 4; // Search

        switch (highMode) {
            case 1: { // First move (Luffy: go to emptiest quadrant)
                dir = chooseEmptyQuadrant();
                dist = 2;
                firstMoveDone = true;
                updatePosition(dir, dist);
                last_dir = dir;
                return;
            }
            case 2: { // Engage (Oracle): horizontal zig-zag with occasional vertical dodge
                if ((turn_counter % 5) == 0) {
                    dir = (rand() % 2) ? 1 : 3; // N or S
                } else {
                    dir = (rand() % 2) ? 2 : 4; // E or W
                }
                dist = 1;
                updatePosition(dir, dist);
                last_dir = dir;
                return;
            }
            case 3: { // Pressure (Oracle): rotating directions
                dir = ((turn_counter / 3) % 4) + 1; // 1..4 => N,E,S,W
                dist = 1;
                updatePosition(dir, dist);
                last_dir = dir;
                return;
            }
            case 4:
            default: { // Search (Oracle spiral + Luffy fallback strategy cycle)
                // Blend: spiral sweep, and every 10 turns run a Luffy cycle burst
                turnsTaken++;
                if ((turnsTaken % 10) == 9) {
                    strategyMode = (strategyMode + 1) % 3; // 0=furthest,1=zigzag,2=random
                }

                int sub = strategyMode;
                switch (sub) {
                    case 0: { // Furthest away (Luffy)
                        chooseFurthestAway(dir, dist);
                        break;
                    }
                    case 1: { // Zig-zag (Luffy)
                        dir = (turnsTaken % 2 == 0) ? 2 : 4;
                        dist = 1;
                        break;
                    }
                    case 2:
                    default: { // Spiral sweep (Oracle) + random fallback
                        dir = sweep_dir;
                        dist = 1;
                        sweep_count++;
                        if (sweep_count >= sweep_length) {
                            sweep_dir = (sweep_dir % 4) + 1;
                            sweep_count = 0;
                            sweep_turns++;
                            if (sweep_turns % 2 == 0) {
                                sweep_length++;
                            }
                        }
                        break;
                    }
                }

                // If movement blocked by obstacle memory, dodge
                int nr = self_row, nc = self_col;
                if (dir == 1) nr--; else if (dir == 2) nc++; else if (dir == 3) nr++; else if (dir == 4) nc--;
                if (!is_passable(nr, nc)) {
                    mode_toggle = !mode_toggle;
                    dir = mode_toggle ? 1 : 2; // N/E dodge
                    dist = 1;
                }

                updatePosition(dir, dist);
                last_dir = dir;
                return;
            }
        }
    }

private:
    enum class Mode { Search, Pressure, Engage };

    // Oracle-style mode and tracking
    Mode mode;
    int last_dir;
    int turn_counter;
    std::unordered_map<int, EnemyTrack> tracks;
    bool has_target = false;
    int predicted_row = -1;
    int predicted_col = -1;

    // Oracle spiral sweep
    int sweep_length;
    int sweep_count;
    int sweep_turns;
    int sweep_dir;

    bool kiting_toggle;

    // Luffy-style
    int strategyMode;   // 0=furthest-away, 1=zig-zag, 2=spiral/random
    int turnsTaken;
    bool firstMoveDone;
    bool mode_toggle;
    bool has_adjacent_target;
    int target_row, target_col;

    // Shared memory
    int self_row, self_col;
    std::vector<RadarObj> lastRadarScan;
    std::set<std::pair<int,int>> obstacles_memory;

    // Helpers
    void updatePosition(int dir, int dist) {
        if (dir == 1) self_row -= dist;
        else if (dir == 2) self_col += dist;
        else if (dir == 3) self_row += dist;
        else if (dir == 4) self_col -= dist;
    }

    void update_obstacle_memory(const std::vector<RadarObj>& radar_results) {
        for (const auto& obj : radar_results) {
            if (obj.m_type == 'M' || obj.m_type == 'P' || obj.m_type == 'F') {
                obstacles_memory.insert({obj.m_row, obj.m_col});
            }
        }
    }

    bool is_passable(int row, int col) const {
        return obstacles_memory.find({row, col}) == obstacles_memory.end();
    }

    int chooseEmptyQuadrant() {
        int topLeft=0, topRight=0, bottomLeft=0, bottomRight=0;
        for (const auto& obj : lastRadarScan) {
            if (obj.m_type == 'R') {
                if (obj.m_row < self_row && obj.m_col < self_col) topLeft++;
                else if (obj.m_row < self_row && obj.m_col >= self_col) topRight++;
                else if (obj.m_row >= self_row && obj.m_col < self_col) bottomLeft++;
                else bottomRight++;
            }
        }
        int minCount = std::min(std::min(topLeft, topRight), std::min(bottomLeft, bottomRight));
        if (minCount == topLeft) return 1;   // NW
        if (minCount == topRight) return 2;  // NE
        if (minCount == bottomLeft) return 4;// SW
        return 3;                            // SE
    }

    void chooseFurthestAway(int& dir, int& dist) {
        std::vector<int> dirs = {1,2,3,4};
        double bestScore = -1;
        int bestDir = 1;
        int bestDist = 1;

        for (int d : dirs) {
            int r = self_row, c = self_col;
            if (d == 1) r--; else if (d == 2) c++;
            else if (d == 3) r++; else if (d == 4) c--;

            double totalDist = 0;
            int count = 0;
            for (const auto& obj : lastRadarScan) {
                if (obj.m_type == 'R') {
                    double dman = std::abs(r - obj.m_row) + std::abs(c - obj.m_col);
                    totalDist += dman;
                    count++;
                }
            }
            double avgDist = (count > 0) ? totalDist / count : 0;
            avgDist += (rand() % 3 - 1); // small noise

            if (avgDist > bestScore) {
                bestScore = avgDist;
                bestDir = d;
                bestDist = 1;
            }
        }

        dir = bestDir;
        dist = bestDist;
    }
};

// Factory function
extern "C" RobotBase* create_robot() {
    return new Robot_Atlus();
}
